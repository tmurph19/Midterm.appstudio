/*
incomeBracket - Uses just Controls, if/else. Gets income, control 
output using template literal ‘With you income of $XX, you are 
in a tax bracket of XX%”. Brackets: 
a)  income less than $30,000, tax bracket 8% 
b)  income less than $99,999, tax bracket 15% 
c) income $99,999 or above, tax bracket 25%
*/


/*
btnSubmit.onclick=function(){
  if (0 <= Number(inptIncome.value) < 30000) {
    lblAnswer.value = `With your income of ${inptIncome.value}, you are in a tax bracket of 8%.`
} 
  else if (30000 <= Number(inptIncome.value) < 99999) {
    lblAnswer.value = `With your income of ${inptIncome.value}, you are in a tax bracket of 15%.`
}
  else if (99999 <= Number(inptIncome.value)) {
    lblAnswer.value = `With your income of ${inptIncome.value}, you are in a tax bracket of 25%.`
}
  else 
    lblAnswer.value = `no tax bracket.`
}


btnGoAgain.onclick=function(){
  inptIncome.value = 0
  inptIncome.value = Number(prompt("Enter a new number.")
  if (0 <= Number(inptIncome.value) < 30000) {
    lblAnswer.value = `With your income of ${inptIncome.value}, you are in a tax bracket of 8%.`
} 
  else if (30000 <= Number(inptIncome.value) < 99999) {
    lblAnswer.value = `With your income of ${inptIncome.value}, you are in a tax bracket of 15%.`
}
  else if (99999 <= Number(inptIncome.value)) {
    lblAnswer.value = `With your income of ${inptIncome.value}, you are in a tax bracket of 25%.`
}
  else 
    lblAnswer.value = `no tax bracket.`
}
*/

