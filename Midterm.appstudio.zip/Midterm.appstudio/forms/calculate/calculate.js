/*
calculate - No Controls. uses function calcAvgSquare(x,y,z), 3
numbers from user, calculates (average or 3 * first number
squared), return answer to main program, input and output
outside of function using template literal in form: The
answer using 10, 20, and 30 is 2000. Extra XP: 150 add
randomMultiply func (num * random number). Ask user
which they want to do: randomMultiply or calcAvgSquare.
*/

/*
function calcAvgSquare (x,y,z) {
  return ((x+y+z)/3)*(Math.pow(x,2))
}

let num1 = Number(prompt("Enter a number."))
let num2 = Number(prompt("Enter a number."))
let num3 = Number(prompt("Enter a number."))

let calculation = calcAvgSquare(num1,num2,num3)

alert(`The answer using ${num1}, ${num2}, and ${num3} is ${calculation}.`)

*/