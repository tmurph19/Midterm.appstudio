/*
animals - used an array, array contains animals, gets name of
a flying animal from user and adds to end of array; outputs
the last animal to the console in form: The Last Animal is
Eagle. User can input using any mix of case. Extra 
XP: 150 - for loop that runs program twice.
*/

/*
let animals = ["dog", "cat", "horse", "mouse", "pig", "cow", "ferret", "lizard", "frog"]

let flyingAnimal = prompt("Enter the name of any flying animal.")
flyingAnimal = flyingAnimal.toLowerCase()

animals.push(flyingAnimal)

let lastAnimal = animals[animals.length - 1]

alert(`The last animal is ${lastAnimal}.`)
*/


